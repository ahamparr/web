# Welcome Page (Static Deploy)

This folder is a self-contained landing page. Deploy the four files below into your web root (or a subfolder) on cPanel:

- `index.html`
- `style.css`
- `script.js`
- `assets/Scene.mp3`

Optional but recommended for Apache hosts:
- `.htaccess` (disables directory listing and rewrites all non-asset requests to `index.html`).

Optional staging-only crawl block:
- `robots.txt` with:
  ```
  User-agent: *
  Disallow: /
  ```

If you deploy to a subfolder (e.g., `/welcome`), keep the relative paths intact and place `.htaccess` inside that folder.
